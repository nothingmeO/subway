import 'package:flutter/material.dart';
import 'package:my_project/screen/subway_info.dart';
import 'package:provider/provider.dart';

class subwayScreen extends StatefulWidget {

  @override  
  _SubwayScreenState createState() => _SubwayScreenState();
}

class _SubwayScreenState extends State<subwayScreen> {
  final controller = ScrollController();
  double offset = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.addListener(onScroll);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    controller.dispose();
    super.dispose();
  }

  void onScroll() {
    setState(() {
      offset = (controller.hasClients) ? controller.offset : 0;
    });
  }

  @override
  Widget build(BuildContext context) {

    return ChangeNotifierProvider(
      create: (_) => MyData(),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('지하철 도착 정보'),
        ),
        body: SingleChildScrollView(
          controller: controller,
          child: Column(
            children: <Widget>[
              Container(
                color: Colors.white,
                height: 100,
                child: Row(
                  children: <Widget>[
                    Icon(Icons.subway, size: 60, color: Colors.lightGreen[400],),
                    Consumer<MyData>(
                      builder: (context, myData, child) {
                        return Text(
                          myData.statnNm + '역',
                          style: TextStyle(fontSize: 50,),
                        );
                      },
                    ),
                  ],
                ),
              ),
              Container(
                height: 80,
                color: Colors.yellow[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[0],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[0] == '전역 도착' || myData.arvlMsg[0] == '전역 출발' || myData.arvlMsg[0] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[0],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[0],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                height: 80,
                color: Colors.lightBlue[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[1],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[1] == '전역 도착' || myData.arvlMsg[1] == '전역 출발' || myData.arvlMsg[1] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[1],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[1],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                height: 80,
                color: Colors.yellow[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[2],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[2] == '전역 도착' || myData.arvlMsg[2] == '전역 출발' || myData.arvlMsg[2] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[2],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[2],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                height: 80,
                color: Colors.lightBlue[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[3],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[3] == '전역 도착' || myData.arvlMsg[3] == '전역 출발' || myData.arvlMsg[3] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[3],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[3],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),Container(
                height: 80,
                color: Colors.yellow[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[4],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[4] == '전역 도착' || myData.arvlMsg[4] == '전역 출발' || myData.arvlMsg[4] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[4],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[4],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                height: 80,
                color: Colors.lightBlue[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[5],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[5] == '전역 도착' || myData.arvlMsg[5] == '전역 출발' || myData.arvlMsg[5] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[5],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[5],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),Container(
                height: 80,
                color: Colors.yellow[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[6],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[6] == '전역 도착' || myData.arvlMsg[6] == '전역 출발' || myData.arvlMsg[6] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[6],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[6],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                height: 80,
                color: Colors.lightBlue[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[7],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[7] == '전역 도착' || myData.arvlMsg[7] == '전역 출발' || myData.arvlMsg[7] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[7],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[7],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),Container(
                height: 80,
                color: Colors.yellow[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[8],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[8] == '전역 도착' || myData.arvlMsg[8] == '전역 출발' || myData.arvlMsg[8] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[8],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[8],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                height: 80,
                color: Colors.lightBlue[100],
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            return Text(
                              myData.trainLineNm[9],
                              style: TextStyle(fontSize: 20),
                            );
                          },
                        ),
                        Consumer<MyData>(
                          builder: (context, myData, child) {
                            if(myData.arvlMsg[9] == '전역 도착' || myData.arvlMsg[9] == '전역 출발' || myData.arvlMsg[9] == '전역 진입')
                            {
                              return Text(
                                myData.arvlMsg[9],
                                style: TextStyle(fontSize: 16, color: Colors.red),
                              );
                            } else {
                              return Text(
                                myData.arvlMsg[9],
                                style: TextStyle(fontSize: 16),
                              );
                            };
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}