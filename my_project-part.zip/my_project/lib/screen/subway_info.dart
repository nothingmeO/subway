import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:xml2json/xml2json.dart';
import 'package:my_project/widget/zoom_image.dart';
import 'package:my_project/screen/subway_screen.dart';

late String subwayName;

class subwayInfo extends StatefulWidget {

  @override
  _SubwayInfoState createState() => _SubwayInfoState();
}

class _SubwayInfoState extends State<subwayInfo> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('지하철 노선도'),
      ),
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16),
            child: ZoomImage(),
          ),
          const Text(
            '검색할 역이름',
            style: TextStyle(fontSize: 30.0),
          ),
          Container(
            child: TextField(
              maxLength: 10,
              maxLines: 1,
              onChanged: (value) {
                subwayName = value;
              },
            ),
          ),
          TextButton(
            child: Column(
              children: [
                Icon(Icons.search, size: 40,),
                Text('검색'),
              ],
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => subwayScreen()),
              );
            },
            style: TextButton.styleFrom(primary: Colors.white, backgroundColor: Colors.lightBlue),
          ),
        ],
      ),
    );
  }
}

class MyData extends ChangeNotifier {
  String statnNm = '';
  List trainLineNm = ['', '', '', '', '', '', '', '', '', ''];
  List arvlMsg = ['', '', '', '', '', '', '', '', '', ''];
  int statnFid = 0;
  int statnTid = 0;
  int statnId = 0;
  int rowNum = 0;

  MyData() {
    _getRequest().then((value) {
      notifyListeners();
    });
  }

  Future<void> _getRequest() async {

    String Url = 'http://swopenAPI.seoul.go.kr/api/subway/4162484a53646b723930626b744145/xml/realtimeStationArrival/0/10/$subwayName';

    var url = Uri.parse(Url);
    http.Response response = await http.get(
      url,
    );

    var statusCode = response.statusCode;
    if (statusCode == 200) {
      var responseBody = utf8.decode(response.bodyBytes);
      getXMLData(responseBody);
    }
  }

  void getXMLData(String xmlData) {
    
    Xml2Json xml2json = Xml2Json();
    xml2json.parse(xmlData);
    var json = xml2json.toParker();

    var data1 = jsonDecode(json);
    List data2 = data1['realtimeStationArrival']['row'];
    Map data3 = data2[0];
    print(data3);

    statnNm = data2[0]['statnNm'];
    for (var i = 0; i < data2.length; i++)
    {
      trainLineNm[i] = data2[i]['trainLineNm'];
      arvlMsg[i] = data2[i]['arvlMsg2'];
    }
    for (var i = data2.length; i < 10; i++)
    {
      trainLineNm[i] = '';
      arvlMsg[i] = '';
    }
  }
}