import 'package:flutter/material.dart';

class homeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<homeScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('설명서'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Text('간단한 설명서 입니다.', style: TextStyle(fontSize: 40),),
            Column(
              children: [
                Text('1. 좌측 하단에 지하철 검색 탭을 선택합니다.', style: TextStyle(fontSize: 15),),
                Text('2. 검색할 지하철역 이름을 기입하고 검색을 누릅니다.', style: TextStyle(fontSize: 15),),
                Text('3. 다른 지하철역을 검색하고 싶으면 뒤로가기를 누릅니다.', style: TextStyle(fontSize: 15),),
              ],
            ),
          ],
        ),
      ),
    );
  }
}